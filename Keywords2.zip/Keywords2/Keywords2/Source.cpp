#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>

using namespace std;

int main()
{
	//Variable set up
	string PlayerName;
	int FailedGuess = 3;
	int FailedRounds = 0;
	string Guess = "";
	string GuessedLetters;
	

// Display Title of the program to the user
	cout << "\t\t\tWelcome to Keywords 2!\n\n" << endl;

// Ask the recruit to log in using their name
	cout << "Please enter your name before we can begin" << endl;
	cin >> PlayerName;

// Hold the recruit's name in a var, and address them by it throughout the simulation.
	cout << "Hello " << PlayerName << "!" << endl;

// Display an overview of what Keywords II is to the recruit
	cout << "As you may already know, Keywords 2 is a training simulation designed to " << endl;
	cout << "improve an agents ability to decode commonly used keywords." << endl;

// Display directions to the recruit on how to use Keywords
	cout << "You must correctly guess three randomly selected keywords. " << endl;
	cout << "If you make 3 mistakes, that's game over!" << endl;
	cout << "" << endl;
	cout << "Beginning Simulation..." << endl;

	


// Create a collection of 10 words you had written down manually
	enum fields {WORD, HINT, NUM_FIELDS};
	const int NUM_WORDS = 10;
	const string WORDS[NUM_WORDS][NUM_FIELDS] =
	{
		{"Hero", "Please ban RNG"},
		{"Destination", "Final ____"},
		{"Legacy", "Everyone hopes theirs is lasting"},
		{"Unfortunate", "A series of ____ events"},
		{"Water", "Stay hydrated"},
		{"Swamp", "Get out of it"},
		{"Zebra", "The first z word that comes to your head"},
		{"Odyssey", "The first game console"},
		{"Flash", "Final ____!"},
		{"Aerial", "SHFFL"},
		
	};
	
	
// Create an int var to count the number of simulations being run starting at 1
	int SimAmount = 1;
	
// Display the simulation # is starting to the recruit.
GameLoop:
	FailedRounds = 0;
	cout << "Initiating simulation #" << SimAmount << endl;

// Pick new 3 random words from your collection as the secret code word the recruit has to guess. 
	srand(static_cast<unsigned int>(time(0)));
	
	for (int i = 0; i < 3; i++)
	{
		int choice = (rand() % NUM_WORDS);
		/*int choice2 = (rand() % NUM_WORDS);
		int choice3 = (rand() % NUM_WORDS);*/

		string theWord = WORDS[choice][WORD];
		string theHint = WORDS[choice][HINT];
		/*string theWord2 = WORDS[choice2][WORD];
		string theHint2 = WORDS[choice2][HINT];
		string theWord3 = WORDS[choice3][WORD];
		string theHint3 = WORDS[choice3][HINT];*/
		/*cout << theWord << endl;*/

		if (!Guess.empty())
		{
			Guess.clear();
		}
		
		for (int i = 0; i < theWord.length(); i++)
		{
			Guess += '_';
		}
		
		// While recruit hasn�t made too many incorrect guesses and hasn�t guessed the secret word
		while (FailedGuess > 0 && Guess != theWord)
		{
			//     Tell recruit how many incorrect guesses he or she has left
			cout << "You have " << FailedGuess << " tries left!" << endl;

			//     Show recruit the letters he or she has guessed
			cout << "Here are the letters you have guessed so far." << endl;
			cout << GuessedLetters << endl;

			//     Show player how much of the secret word he or she has guessed
			cout << "Here is the word so far..." << endl;
			cout << Guess << endl;


			//     Get recruit's next guess
			cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
			cin.clear();
			cout << "Enter your next guess plz" << endl;
			char GuessLetter;
			cin >> GuessLetter;

			//     While recruit has entered a letter that he or she has already guessed
			while (GuessedLetters.find(GuessLetter) != string::npos)
			{
				//          Get recruit �s guess
				cout << "You already guessed that, FOOL! Enter again plz" << endl;
				cin >> GuessLetter;
			}

			//     Add the new guess to the group of used letters
			GuessedLetters += GuessLetter;

			//     If the guess is in the secret word
			if (theWord.find(GuessLetter) != string::npos)
			{
				//          Tell the recruit the guess is correct
				cout << "Congrats, you got it." << endl;

				//          Update the word guessed so far with the new letter
				for (int i = 0; i < theWord.length(); i++)
				{
					if (theWord[i] == GuessLetter)
					{
						Guess[i] = GuessLetter;
					}
				}
			}
			//     Otherwise
			else
			{

				//          Tell the recruit the guess is incorrect
				cout << "You got it wrong." << endl;
				//          Increment the number of incorrect guesses the recruit has made
				FailedGuess--;
			}
		}

		if (FailedGuess == 0)
		{
			FailedRounds++;
		}

		GuessedLetters.clear();
		FailedGuess = 3;
	}

	// If the recruit has made too many incorrect guesses
	if (FailedRounds == 3)
	{
		//     Tell the recruit that he or she has failed the Keywords II course.
		cout << "You have failed, consider yourself blacklisted." << endl;
	}
	// Otherwise
	else
	{
		//     Congratulate the recruit on guessing the secret words
		cout << "Well, guess you're not that bad. Welome to the team." << endl;
	}
	// Ask the recruit if they would like to run the simulation again
	cout << "Are you brave enough to try again?" << endl;
	char again;
	cin >> again;
	// If the recruit wants to run the simulation again
	if (again == 'Y' || again == 'y')
	{
		//     Increment the number of simulations ran counter
		SimAmount++;
		//     Move program execution back up to // Display the simulation # is starting to the recruit.
		goto GameLoop;
	}
	// Otherwise 
	else
	{
		//     Display End of Simulations to the recruit
		cout << "End of simulations. Number of simulations run " << SimAmount << endl;
		//     Pause the Simulation with press any key to continue
		system("pause");
	}
}